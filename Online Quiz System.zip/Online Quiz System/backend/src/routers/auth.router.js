import express from "express";
import { signup,login,logout,updateProfile,checkAuth } from "../controllers/auth.controller.js";
import {validate} from "../middlewares/userValidate.middleware.js"
import {protectRoute} from "../middlewares/protectRoute.js"  


const router = express.Router();

router.post("/signup",validate,signup)  
router.post("/login",login)
router.post("/logout",logout)
router.put("/update-profile",protectRoute,updateProfile) 
router.get("/check",protectRoute,checkAuth);  




export default router;